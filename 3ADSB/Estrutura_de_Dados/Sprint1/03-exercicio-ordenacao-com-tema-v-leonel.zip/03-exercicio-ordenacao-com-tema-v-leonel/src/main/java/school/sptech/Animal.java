package school.sptech;

public class Animal {
    private Integer id;
    private String nome;
    private String especie;
    private Double peso;
    private Integer idade;
    private Double tamanho;

    public Animal() {
    }

    public Animal(Integer id, String nome, String especie, Double peso, Integer idade, Double tamanho) {
        this.id = id;
        this.nome = nome;
        this.especie = especie;
        this.peso = peso;
        this.idade = idade;
        this.tamanho = tamanho;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public Double getPeso() {
        return peso;
    }

    public void setPeso(Double peso) {
        this.peso = peso;
    }

    public Integer getIdade() {
        return idade;
    }

    public void setIdade(Integer idade) {
        this.idade = idade;
    }

    public Double getTamanho() {
        return tamanho;
    }

    public void setTamanho(Double tamanho) {
        this.tamanho = tamanho;
    }

    public void exibirInformacoes() {
        System.out.println("ID: " + id);
        System.out.println("Nome: " + nome);
        System.out.println("Espécie: " + especie);
        System.out.println("Peso: " + peso + " kg");
        System.out.println("Idade: " + idade + " anos");
        System.out.println("Tamanho: " + tamanho + " cm");
    }
}
