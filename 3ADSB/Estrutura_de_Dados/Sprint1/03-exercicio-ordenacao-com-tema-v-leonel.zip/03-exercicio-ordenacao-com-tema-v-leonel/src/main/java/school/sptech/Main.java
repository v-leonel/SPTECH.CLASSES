package school.sptech;

public class Main {
  public static void main(String[] args) {
    Animal[] zoologico = criarZoologico();

    System.out.println("Animais ordenados por idade (Selection Sort):");
    selectionSort(zoologico);
    exibirTodosAnimais(zoologico);

    System.out.println("\n-------------------------\n");

    zoologico = criarZoologico();

    System.out.println("Animais ordenados por peso (Bubble Sort):");
    bubbleSort(zoologico);
    exibirTodosAnimais(zoologico);

    System.out.println("\n-------------------------\n");
    System.out.println("Animais ordenados por peso em ordem decrescente(Bubble Sort):");
    bubbleSortDecrescente(zoologico);
    exibirTodosAnimais(zoologico);

    zoologico = criarZoologico();

    System.out.println("\n-------------------------\n");
    System.out.println("Animais ordenados por idade (Insertion Sort):");
    insertionSort(zoologico);
    exibirTodosAnimais(zoologico);

    zoologico = criarZoologico();

    System.out.println("\n-------------------------\n");
    System.out.println("Procurando um animal pela idade usando pesquisa binária:");
    int idadeProcurada = 6;
    int resultado = pesquisaBinaria(zoologico, idadeProcurada);

    if (resultado != -1) {
      System.out.println("Animal encontrado no índice: " + resultado);
      zoologico[resultado].exibirInformacoes();
    } else {
      System.out.println("Nenhum animal encontrado com a idade especificada.");
    }
  }

  public static void selectionSort(Animal[] zoologico) {
    int n = zoologico.length;

    for (int i = 0; i < n - 1; i++) {
      int min = i;

      for (int j = i + 1; j < n; j++) {
        if (zoologico[j].getIdade() < zoologico[min].getIdade()) {
          min = j;
        }
      }

      Animal aux = zoologico[i];
      zoologico[i] = zoologico[min];
      zoologico[min] = aux;
    }
  }

  public static void bubbleSort(Animal[] zoologico) {
    int n = zoologico.length;

    for (int i = 0; i < n - 1; i++) {
      for (int j = 0; j < n - 1 - i; j++) {
        if (zoologico[j].getPeso() > zoologico[j + 1].getPeso()) {
          Animal aux = zoologico[j];
          zoologico[j] = zoologico[j + 1];
          zoologico[j + 1] = aux;
        }
      }
    }
  }

  public static void insertionSort(Animal[] zoologico) {
    int n = zoologico.length;

    for (int i = 1; i < n; i++) {
      Animal x = zoologico[i];
      int j = i - 1;
      while (j >= 0 && zoologico[j].getIdade() > x.getIdade()) {
        zoologico[j + 1] = zoologico[j];
        j = j - 1;
      }
      zoologico[j + 1] = x;
    }
  }


  public static int pesquisaBinaria(Animal[] zoologico, int idade) {
    int indinf = 0;
    int indsup = zoologico.length - 1;

    while (indinf <= indsup) {
      int meio = (indinf + indsup) / 2;

      if (zoologico[meio].getIdade() == idade) {
        return meio;
      } else if (idade < zoologico[meio].getIdade()) {
        indsup = meio - 1;
      } else {
        indinf = meio + 1;
      }
    }

    return -1;
  }


  public static void bubbleSortDecrescente(Animal[] zoologico) {
    int n = zoologico.length;

    for (int i = 0; i < n - 1; i++) {
      for (int j = 0; j < n - 1 - i; j++) {
        if (zoologico[j].getPeso() < zoologico[j + 1].getPeso()) {
          Animal aux = zoologico[j];
          zoologico[j] = zoologico[j + 1];
          zoologico[j + 1] = aux;
        }
      }
    }
  }



  public static Animal[] criarZoologico() {
    return new Animal[]{
            new Animal(1, "Simba", "Leão", 190.5, 5, 2.00),
            new Animal(2, "Manny", "Elefante", 5400.0, 10, 5.00),
            new Animal(3, "Diego", "Tigre", 310.0, 7, 185.00),
            new Animal(4, "Gloria", "Hipopótamo", 1500.0, 4, 3.40),
            new Animal(5, "Alex", "Leão", 200.0, 6, 2.35),
            new Animal(6, "Melman", "Girafa", 1200.0, 8, 6.43),
            new Animal(7, "Marty", "Zebra", 400.0, 6, 2.30),
            new Animal(8, "King Julien", "Lêmure", 20.0, 3, 0.45)
    };
  }

  public static void exibirTodosAnimais(Animal[] zoologico) {
    for (Animal animal : zoologico) {
      animal.exibirInformacoes();
      System.out.println();
    }
  }
}
